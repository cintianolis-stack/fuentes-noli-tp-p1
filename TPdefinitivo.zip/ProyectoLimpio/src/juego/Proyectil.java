package juego;

import java.awt.Color;

import java.awt.Image;
import entorno.Entorno;
import entorno.Herramientas;



public class Proyectil {

    private double x;
    private double y;

    private double dx;
    private double dy;

    private Image imagenProyectil;
    
    // CONSTRUCTOR

    public Proyectil(
            int xInicial,
            int yInicial,
            int mouseX,
            int mouseY) {

        x = xInicial;
        y = yInicial;

        double distancia = Math.sqrt(
                Math.pow(mouseX - x, 2) +
                Math.pow(mouseY - y, 2));

        this.imagenProyectil = Herramientas.cargarImagen("juego/proyectil.png");
        
        // evitar división por 0

        if (distancia == 0) {

            distancia = 1;
        }

        
        // velocidad proyectil

        dx = (mouseX - x) / distancia * 10;
        dy = (mouseY - y) / distancia * 10;
    }

    
    // MOVER

    public void mover() {

        x += dx;
        y += dy;
    }

    
    // MOVER IZQUIERDA

    public void moverIzquierda(int valor) {

        x -= valor;
    }

    
    // DIBUJAR

    //public void dibujar(Entorno e) {

        //e.dibujarCirculo(
                //(int)x,
                //(int)y,
               // 8,
               // Color.YELLOW);
    public void dibujar(Entorno entorno) {
        if (this.imagenProyectil != null) {
            
            // --- 📐 DEFINIR EL TAMAÑO DE LA COLISIÓN DEL DISPARO ---
            // Pon aquí los píxeles reales que quieres que mida el proyectil en tu juego.
            // Por ejemplo, si quieres que el misil/bala mida 15 píxeles de ancho en la pantalla:
            double anchoDeseadoEnJuego = 15.0;

            // --- 🧮 EL TRUCO DE LA ESCALA AUTOMÁTICA ---
            // Reemplaza el 50.0 de abajo por los píxeles de ancho que mide tu ARCHIVO "disparo.png" en tu PC.
            // Si la foto original de tu disparo mide 64 píxeles de ancho, pon 64.0.
            double anchoOriginalDeLaImagen = 150.0; 

            // Calculamos la escala exacta división mediante
            double escalaProyectil = anchoDeseadoEnJuego / anchoOriginalDeLaImagen;

            // Dibujamos la imagen con su escala correspondiente. 
            // Si tu proyectil tiene un ángulo de rotación para seguir al mouse, cambia el 0 por tu variable de ángulo.
            entorno.dibujarImagen(this.imagenProyectil, this.x, this.y, 0, escalaProyectil);
            
        } else {
            // Respaldo por si la imagen falla (reemplaza por tu círculo/rectángulo original)
            entorno.dibujarCirculo(this.x, this.y, 10, java.awt.Color.YELLOW);
        }
    }
    

    
    // COLISION ENEMIGO

    public boolean colisiona(Enemigo enemigo) {

        return Math.abs(x - enemigo.getX()) < 20 &&
               Math.abs(y - enemigo.getY()) < 20;
    }

    
    // FUERA PANTALLA

    public boolean fueraPantalla() {

        return x < 0 ||
               x > 800 ||
               y < 0 ||
               y > 600;
    }
}