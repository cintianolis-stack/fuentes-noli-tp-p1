package juego;

import java.awt.Color;


import java.awt.Image; 
import entorno.Entorno;
import entorno.Herramientas;



public class Piso {

    
    // VARIABLES

    private int x;
    private int y;

    private int ancho;
    private int alto;

    
    private Image imagenIsla;
    
    // CONSTRUCTOR

    public Piso(int x, int y, int ancho, int alto) {

        this.x = x;
        this.y = y;

        this.ancho = ancho;
        this.alto = alto;
        
        this.imagenIsla = Herramientas.cargarImagen("juego/isla.png");
        
    }

    
    // DIBUJAR

    //public void dibujar(Entorno e) {

        //e.dibujarRectangulo(x, y, ancho, alto, 0, Color.WHITE);

        
    public void dibujar(Entorno entorno) {
        if (this.imagenIsla != null) {
            // Dibujamos la imagen. El 1.0 es la escala, si tu isla se ve muy grande 
            // o muy chica, puedes cambiarlo por ejemplo a 0.5 o 1.2
            entorno.dibujarImagen(this.imagenIsla, this.x, this.y, 0, 0.3);
        } else {
            // Respaldo: Si la imagen no carga, dibuja el rectángulo gris de antes
            entorno.dibujarRectangulo(this.x, this.y, this.ancho, this.alto, 0, java.awt.Color.GRAY);
        }
    }
        
        

    
    // MOVER IZQUIERDA

    public void moverIzquierda(int valor) {

        x -= valor;
    }

    
    // GET X

    public int getX() {

        return x;
    }

    
    // GET Y

    public int getY() {

        return y;
    }

    
    // GET ANCHO

    public int getAncho() {

        return ancho;
    }

    
    // GET ALTO

    public int getAlto() {

        return alto;
    }
}