package juego;

import java.awt.Color;

import java.awt.Image;
import entorno.Entorno;
import entorno.Herramientas;

public class Castillo {

    private int x;
    private int y;

    private int ancho;
    private int alto;
    private Image imagenCastillo;

    public Castillo(int x, int y, int ancho, int alto) {

        this.x = x;
        this.y = y;

        this.ancho = ancho;
        this.alto = alto;
        
        this.imagenCastillo = Herramientas.cargarImagen("juego/castillo.png");
    }

    //public void dibujar(Entorno e) {

        //e.dibujarRectangulo(x, y, ancho, alto, 0, Color.GRAY);
        
    public void dibujar(Entorno entorno) {
        if (this.imagenCastillo != null) {
            entorno.dibujarImagen(this.imagenCastillo, this.x, this.y, 0, 0.60);
        } else {
            entorno.dibujarRectangulo(this.x, this.y, 120, 180, 0, java.awt.Color.BLUE);
        }
    }
        
        
        
        
        
    

    
    // MOVER IZQUIERDA

    public void moverIzquierda(int valor) {

        x -= valor;
    }

    public boolean colisiona(Personaje p) {

        return Math.abs(x - p.getX()) < 80 &&
               Math.abs(y - p.getY()) < 100;
    }
}