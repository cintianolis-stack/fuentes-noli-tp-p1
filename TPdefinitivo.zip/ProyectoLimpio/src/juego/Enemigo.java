package juego;

import java.awt.Color;

import java.awt.Image; 
import entorno.Entorno;
import entorno.Herramientas;


public class Enemigo {

    private int x;
    private int y;

    private int velocidad;

    private Image imagenEnemigo;
    
    public Enemigo(int x, int y, int velocidad) {

        this.x = x;
        this.y = y;

        this.velocidad = velocidad;
        
        this.imagenEnemigo = Herramientas.cargarImagen("juego/enemigo.png");
    }

    
    // MOVER

    public void mover() {

        x += velocidad;
    }

    
    // MOVER IZQUIERDA

    public void moverIzquierda(int valor) {

        x -= valor;
    }

    
    // DIBUJAR

    //public void dibujar(Entorno e) {

        //e.dibujarCirculo(x, y, 20, Color.RED);
        
    public void dibujar(Entorno entorno) {
        if (this.imagenEnemigo != null) {
          
            entorno.dibujarImagen(this.imagenEnemigo, this.x, this.y, 0, 0.2);
        } else {
            
            entorno.dibujarRectangulo(this.x, this.y, 30, 30, 0, java.awt.Color.RED);
        }
    }
        

    
    // COLISION PERSONAJE

    public boolean colisiona(Personaje p) {

        return Math.abs(x - p.getX()) < 30 &&
               Math.abs(y - p.getY()) < 40;
    }

    
    // FUERA PANTALLA

    public boolean fueraPantalla() {

        return x < -100 || x > 900;
    }

    
    // GET X

    public int getX() {

        return x;
    }

    
    // GET Y

    public int getY() {

        return y;
    }
}